(() => {
  // src/core/urls.ts
  var STATE = "-------en-20--1--txt-txIN---------------1";
  function buildUrls(host = "dwso.revealdigital.org") {
    const base = `https://${host}/?`;
    return {
      collection: (cl = "CL1") => `${base}a=cl&cl=${cl}&e=${STATE}`,
      publication: (sp, cl = "CL1") => `${base}a=cl&cl=${cl}&sp=${sp}&ai=1&e=${STATE}`,
      issue: (docId) => `${base}a=d&d=${docId}&e=${STATE}`,
      pagePdf: (docId, pageId) => `${base}a=is&oid=${docId}.${pageId}&type=staticpdf&e=${STATE}`,
      home: () => `https://${host}/`
    };
  }
  // src/core/paths.ts
  var MONTH_SHORT = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ];
  function formatDate(date) {
    const yyyy = String(date.year).padStart(4, "0");
    const mmm = date.month >= 1 && date.month <= 12 ? MONTH_SHORT[date.month - 1] : "???";
    const dd = String(date.day).padStart(2, "0");
    return `${yyyy}-${mmm}-${dd}`;
  }
  function buildFolderName(parsed) {
    const date = formatDate(parsed.date);
    if (parsed.volume != null && parsed.issue != null) {
      return `${date}, Vol-${String(parsed.volume).padStart(2, "0")} Iss-${String(parsed.issue).padStart(2, "0")}`;
    }
    return date;
  }
  function buildPageFileName(pageIndex) {
    return `page${String(pageIndex + 1).padStart(2, "0")}.pdf`;
  }
  function issueFolderPath(title, parsed) {
    return `${sanitizeFilename(title)}/${buildFolderName(parsed)}`;
  }
  function sanitizeFilename(name) {
    const HYPHEN = "";
    const SEP = "";
    const cleaned = name.replace(/-/g, HYPHEN).replace(/[<>:"/\\|?*\u0000-\u001f]/g, SEP).replace(/\uE001+/g, " - ").replace(/\uE000/g, "-").replace(/\s+/g, " ").replace(/^[\s-]+|[\s-]+$/g, "").trim();
    return cleaned || "Untitled";
  }
  // src/core/veridian.ts
  var MONTHS = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];
  function parsePublications(html) {
    const out = [];
    const ulRe = /<ul[^>]*class="publicationbrowserlist[^"]*"[^>]*>([\s\S]*?)<\/ul>/gi;
    const linkRe = /<a\s+([^>]*?)href="[^"]*sp=([A-Z0-9]+)&amp;ai=1[^"]*"[^>]*>([\s\S]*?)<\/a>/gi;
    for (const ulMatch of html.matchAll(ulRe)) {
      for (const m of ulMatch[1].matchAll(linkRe)) {
        const attrs = m[1];
        out.push({
          title: decodeHtml(m[3]).trim(),
          sp: m[2],
          locked: /uhialockedlink/.test(attrs)
        });
      }
    }
    return out;
  }
  function parseIssues(html) {
    const out = [];
    const ulRe = /<ul[^>]*id="publicationdocumentslist"[^>]*>([\s\S]*?)<\/ul>/i;
    const linkRe = /<li[^>]*>([\s\S]*?)<\/li>/gi;
    const ulMatch = html.match(ulRe);
    if (!ulMatch)
      return out;
    for (const liMatch of ulMatch[1].matchAll(linkRe)) {
      const li = liMatch[1];
      const a = li.match(/<a\s+[^>]*href="[^"]*a=d&amp;d=([A-Z0-9-]+)&amp;e=[^"]*"[^>]*>([\s\S]*?)<\/a>/i);
      if (!a)
        continue;
      out.push({
        docId: a[1],
        label: decodeHtml(a[2]).trim(),
        locked: /title="Locked"/i.test(li) || /uhialockedlink/.test(li)
      });
    }
    return out;
  }
  function parseIssueLabel(label) {
    const dateMatch = label.match(/(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})/);
    let date = { year: 0, month: 0, day: 0 };
    if (dateMatch) {
      const month = MONTHS.findIndex((m) => m.toLowerCase().startsWith(dateMatch[2].toLowerCase().slice(0, 3)));
      date = {
        year: Number(dateMatch[3]),
        month: month >= 0 ? month + 1 : 0,
        day: Number(dateMatch[1])
      };
    }
    const vol = label.match(/Volume\s+(\d+)/i);
    const iss = label.match(/Issue\s+(\d+)|Number\s+(\d+)/i);
    return {
      date,
      volume: vol ? Number(vol[1]) : null,
      issue: iss ? Number(iss[1] ?? iss[2]) : null
    };
  }
  function extractPageIds(html) {
    const idx = html.indexOf("pageImageSizes");
    if (idx === -1)
      return [];
    let i = html.indexOf(":", idx) + 1;
    while (i < html.length && /\s/.test(html[i]))
      i++;
    if (html[i] !== "{")
      return [];
    const start = i;
    let depth = 0;
    for (;i < html.length; i++) {
      if (html[i] === "{")
        depth++;
      else if (html[i] === "}") {
        depth--;
        if (depth === 0)
          break;
      }
    }
    if (depth !== 0)
      return [];
    try {
      const obj = JSON.parse(decodeHtml(html.slice(start, i + 1)));
      return Object.keys(obj);
    } catch {
      return [];
    }
  }
  function extractPublicationTitle(html) {
    const m = html.match(/<b>Title:<\/b>\s*([^<]*)/i);
    return m ? decodeHtml(m[1]).trim() : null;
  }
  function extractTitleFromIssueHeader(html) {
    const m = html.match(/<div id="documentdisplayheader"[^>]*><h2>([^<]+)<\/h2>/);
    if (!m)
      return null;
    return m[1].split(",")[0]?.trim() ?? null;
  }
  function extractIssueMetadata(html) {
    const meta = {};
    const rowRe = /class="label">([^<]+)<\/div><div class="content">([^<]*)<\/div>/g;
    for (const m of html.matchAll(rowRe)) {
      const label = m[1].trim().toLowerCase();
      const value = m[2].trim();
      if (label === "date")
        meta.date = value;
      else if (label === "volume")
        meta.volume = value ? Number(value) : null;
      else if (label === "number")
        meta.issue = value ? Number(value) : null;
    }
    return meta;
  }
  function decodeHtml(s) {
    return s.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&nbsp;/g, " ");
  }
  // src/core/planner.ts
  function toIssuePlan(title, issue) {
    const parsed = parseIssueLabel(issue.label);
    return {
      title,
      docId: issue.docId,
      label: issue.label,
      parsed,
      locked: issue.locked,
      folderPath: issueFolderPath(title, parsed)
    };
  }
  function singleIssuePlan(title, docId, label, parsed) {
    return {
      title,
      docId,
      label,
      parsed,
      locked: false,
      folderPath: issueFolderPath(title, parsed)
    };
  }
  function planPages(plan, pageIds) {
    return pageIds.map((pageId, i) => ({
      pageId,
      filePath: `${plan.folderPath}/${buildPageFileName(i)}`
    }));
  }
  // src/background/background.ts
  var api = globalThis.browser ?? globalThis.chrome;
  var IS_FIREFOX = typeof globalThis.browser !== "undefined";
  var STATE_KEY = "rdd:v1";
  var DEFAULT_HOST = "dwso.revealdigital.org";
  var ENUMERATION_DELAY_MS = 150;
  var LOG_CAP = 60;
  var KEEPALIVE_MS = 20000;
  var DOWNLOAD_TIMEOUT_MS = 5 * 60 * 1000;
  function freshState() {
    return {
      status: "idle",
      mode: "all",
      host: DEFAULT_HOST,
      startedAt: 0,
      counts: { downloaded: 0, skipped: 0, blocked: 0, failed: 0 },
      plan: { issues: 0 },
      completedIssues: [],
      blockedIssues: [],
      log: []
    };
  }
  var state = freshState();
  var pauseRequested = false;
  var runId = 0;
  var keepAliveTimer = null;
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  function storageGet() {
    return new Promise((resolve, reject) => {
      if (IS_FIREFOX) {
        api.storage.local.get(STATE_KEY).then((r) => resolve(r?.[STATE_KEY] ?? freshState()), reject);
      } else {
        api.storage.local.get(STATE_KEY, (r) => {
          if (api.runtime?.lastError)
            reject(new Error(api.runtime.lastError.message));
          else
            resolve(r?.[STATE_KEY] ?? freshState());
        });
      }
    });
  }
  function storageSet(s) {
    return new Promise((resolve, reject) => {
      if (IS_FIREFOX) {
        api.storage.local.set({ [STATE_KEY]: s }).then(() => resolve(), reject);
      } else {
        api.storage.local.set({ [STATE_KEY]: s }, () => {
          if (api.runtime?.lastError)
            reject(new Error(api.runtime.lastError.message));
          else
            resolve();
        });
      }
    });
  }
  function tabsQuery(info) {
    return new Promise((resolve, reject) => {
      if (IS_FIREFOX) {
        api.tabs.query(info).then(resolve, reject);
      } else {
        api.tabs.query(info, (tabs) => {
          if (api.runtime?.lastError)
            reject(new Error(api.runtime.lastError.message));
          else
            resolve(tabs);
        });
      }
    });
  }
  function tabsGet(tabId) {
    return new Promise((resolve, reject) => {
      if (IS_FIREFOX) {
        api.tabs.get(tabId).then(resolve, reject);
      } else {
        api.tabs.get(tabId, (tab) => {
          if (api.runtime?.lastError)
            reject(new Error(api.runtime.lastError.message));
          else
            resolve(tab);
        });
      }
    });
  }
  function tabsCreate(info) {
    return new Promise((resolve, reject) => {
      if (IS_FIREFOX) {
        api.tabs.create(info).then(resolve, reject);
      } else {
        api.tabs.create(info, (tab) => {
          if (api.runtime?.lastError)
            reject(new Error(api.runtime.lastError.message));
          else
            resolve(tab);
        });
      }
    });
  }
  function tabsUpdate(tabId, info) {
    return new Promise((resolve, reject) => {
      if (IS_FIREFOX) {
        api.tabs.update(tabId, info).then(resolve, reject);
      } else {
        api.tabs.update(tabId, info, (tab) => {
          if (api.runtime?.lastError)
            reject(new Error(api.runtime.lastError.message));
          else
            resolve(tab);
        });
      }
    });
  }
  function tabsSendMessage(tabId, msg) {
    return new Promise((resolve, reject) => {
      if (IS_FIREFOX) {
        api.tabs.sendMessage(tabId, msg).then(resolve, reject);
      } else {
        api.tabs.sendMessage(tabId, msg, (res) => {
          if (api.runtime?.lastError)
            reject(new Error(api.runtime.lastError.message));
          else
            resolve(res);
        });
      }
    });
  }
  function downloadsDownload(opts) {
    return new Promise((resolve, reject) => {
      if (IS_FIREFOX) {
        api.downloads.download(opts).then(resolve, reject);
      } else {
        api.downloads.download(opts, (id) => {
          if (api.runtime?.lastError)
            reject(new Error(api.runtime.lastError.message));
          else
            resolve(id);
        });
      }
    });
  }
  var saving = false;
  var saveQueued = false;
  function saveState() {
    return new Promise((resolve) => {
      const write = () => {
        saving = true;
        storageSet(state).then(() => {
          saving = false;
          if (saveQueued) {
            saveQueued = false;
            write();
          }
          resolve();
        }, () => {
          saving = false;
          saveQueued = false;
          resolve();
        });
      };
      if (saving) {
        saveQueued = true;
        resolve();
        return;
      }
      write();
    });
  }
  function log(line) {
    const t = new Date;
    const hh = String(t.getHours()).padStart(2, "0");
    const mm = String(t.getMinutes()).padStart(2, "0");
    const ss = String(t.getSeconds()).padStart(2, "0");
    state.log.push(`[${hh}:${mm}:${ss}] ${line}`);
    if (state.log.length > LOG_CAP)
      state.log = state.log.slice(-LOG_CAP);
  }
  function keepAliveOn() {
    keepAliveOff();
    keepAliveTimer = setInterval(() => {
      try {
        const p = api.storage.local.get(STATE_KEY);
        if (p && typeof p.catch === "function")
          p.catch(() => {});
      } catch {}
    }, KEEPALIVE_MS);
  }
  function keepAliveOff() {
    if (keepAliveTimer != null) {
      clearInterval(keepAliveTimer);
      keepAliveTimer = null;
    }
  }
  async function ensureArchiveTab(host, wait = true) {
    const tabs = await tabsQuery({ url: "*://*.revealdigital.org/*" });
    let tab = tabs.find((t) => t && t.id != null && /revealdigital\.org/.test(t.url ?? ""));
    if (!tab) {
      tab = await tabsCreate({ url: `https://${host}/` });
    } else if (tab.id != null) {
      try {
        await tabsUpdate(tab.id, { active: true });
      } catch {}
    }
    if (tab?.id == null)
      throw new Error("Couldn't open the Reveal Digital archive.");
    if (wait) {
      for (let i = 0;i < 40; i++) {
        try {
          const t = await tabsGet(tab.id);
          if (t && t.status === "complete")
            break;
        } catch {}
        await sleep(250);
      }
    }
    return tab.id;
  }
  async function withContent(tabId, msg) {
    let lastErr = null;
    for (let i = 0;i < 30; i++) {
      try {
        return await tabsSendMessage(tabId, msg);
      } catch (e) {
        lastErr = e;
        await sleep(250);
      }
    }
    throw new Error("Couldn't reach the archive page. Make sure a Reveal Digital tab is open and you're logged in.");
  }
  async function fetchViaContent(tabId, url) {
    const res = await withContent(tabId, { type: "fetch", url });
    if (!res || !res.ok) {
      const status = res?.status ?? 0;
      throw new Error(status ? `The archive returned HTTP ${status} (login may be required).` : `Couldn't load an archive page (${url}).`);
    }
    return res.text;
  }
  async function probeViaContent(tabId, url) {
    const res = await withContent(tabId, { type: "probe", url });
    return {
      status: res?.status ?? 0,
      contentType: res?.contentType ?? "",
      pdf: Boolean(res?.pdf)
    };
  }
  function downloadOnce(url, filename) {
    return new Promise((resolve, reject) => {
      const pending = new Set;
      let settled = false;
      const onChange = (delta) => {
        if (!delta || !delta.id || !pending.has(delta.id))
          return;
        const cur = delta.state && delta.state.current;
        if (cur === "complete") {
          settled = true;
          clearTimeout(timer);
          api.downloads.onChanged.removeListener(onChange);
          resolve();
        } else if (cur === "interrupted") {
          settled = true;
          clearTimeout(timer);
          api.downloads.onChanged.removeListener(onChange);
          reject(new Error("Download was interrupted."));
        }
      };
      const timer = setTimeout(() => {
        if (!settled) {
          settled = true;
          api.downloads.onChanged.removeListener(onChange);
          reject(new Error("Timed out waiting for the download to finish."));
        }
      }, DOWNLOAD_TIMEOUT_MS);
      api.downloads.onChanged.addListener(onChange);
      downloadsDownload({
        url,
        filename,
        conflictAction: "overwrite",
        saveAs: false
      }).then((id) => {
        pending.add(id);
      }, (e) => {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          api.downloads.onChanged.removeListener(onChange);
          reject(e instanceof Error ? e : new Error(String(e)));
        }
      });
    });
  }
  function parseDocIdFromUrl(url) {
    const m = url.match(/[?&]d=([A-Z0-9-]+)/i);
    return m ? m[1] : null;
  }
  async function runScrape(id, mode, host, startUrl, docId, delayMs, onlyPublic) {
    try {
      const urls2 = buildUrls(host);
      const tabId = await ensureArchiveTab(host);
      await withContent(tabId, { type: "ping" });
      const plans = [];
      if (mode === "all") {
        log("Scanning the full archive…");
        const html = await fetchViaContent(tabId, urls2.collection());
        const pubs = parsePublications(html);
        log(`Found ${pubs.length} newspaper${pubs.length === 1 ? "" : "s"}`);
        for (const pub of pubs) {
          if (id !== runId || pauseRequested)
            return;
          if (onlyPublic && pub.locked) {
            log(`Skipping login-only newspaper: ${pub.title}`);
            continue;
          }
          await sleep(ENUMERATION_DELAY_MS);
          const pubHtml = await fetchViaContent(tabId, urls2.publication(pub.sp));
          const title = extractPublicationTitle(pubHtml) ?? pub.title;
          const issues = parseIssues(pubHtml);
          for (const issue of issues) {
            if (onlyPublic && issue.locked)
              continue;
            plans.push(toIssuePlan(title, issue));
          }
          log(`${title}: ${issues.length} issue${issues.length === 1 ? "" : "s"}`);
          await saveState();
        }
      } else if (mode === "publication") {
        const spMatch = (startUrl ?? "").match(/[?&]sp=([A-Z0-9]+)/i);
        const sp = spMatch ? spMatch[1] : null;
        if (!sp)
          throw new Error("Couldn't find the newspaper code in the page URL — open a newspaper page first.");
        const pubHtml = await fetchViaContent(tabId, urls2.publication(sp));
        const title = extractPublicationTitle(pubHtml) ?? sp;
        const issues = parseIssues(pubHtml);
        for (const issue of issues) {
          if (onlyPublic && issue.locked)
            continue;
          plans.push(toIssuePlan(title, issue));
        }
        log(`${title}: ${issues.length} issue${issues.length === 1 ? "" : "s"}`);
      } else {
        const d = docId ?? parseDocIdFromUrl(startUrl ?? "") ?? undefined;
        if (!d)
          throw new Error("Couldn't find the issue code in the page URL — open an issue page first.");
        const issueHtml = await fetchViaContent(tabId, urls2.issue(d));
        const title = extractTitleFromIssueHeader(issueHtml) ?? host;
        const meta = extractIssueMetadata(issueHtml);
        const label = meta.date ?? d;
        const parsed = {
          date: parseIssueLabel(meta.date ?? "").date,
          volume: meta.volume ?? null,
          issue: meta.issue ?? null
        };
        plans.push(singleIssuePlan(title, d, label, parsed));
      }
      if (id !== runId)
        return;
      state.plan.issues = plans.length;
      log(`Queued ${plans.length} issue${plans.length === 1 ? "" : "s"}`);
      await saveState();
      for (let i = 0;i < plans.length; i++) {
        if (id !== runId)
          return;
        if (pauseRequested)
          return finishAs("paused");
        const plan = plans[i];
        if (state.completedIssues.includes(plan.folderPath)) {
          state.counts.skipped++;
          log(`Already downloaded: ${plan.folderPath}`);
          await saveState();
          continue;
        }
        if (state.blockedIssues.includes(plan.folderPath))
          continue;
        if (plan.locked && onlyPublic)
          continue;
        log(`Starting: ${plan.folderPath}`);
        state.current = { index: i, total: plans.length, label: plan.label, page: 0, totalPages: 0 };
        await saveState();
        const issueHtml = await fetchViaContent(tabId, urls2.issue(plan.docId));
        const pageIds = extractPageIds(issueHtml);
        if (pageIds.length === 0) {
          log(`No pages found for ${plan.folderPath} — skipping`);
          continue;
        }
        const jobs = planPages(plan, pageIds);
        if (state.current)
          state.current.totalPages = jobs.length;
        await saveState();
        let blockedAny = false;
        for (let p = 0;p < jobs.length; p++) {
          if (id !== runId)
            return;
          if (pauseRequested)
            return finishAs("paused");
          const job = jobs[p];
          if (state.current)
            state.current.page = p + 1;
          const pdfUrl = urls2.pagePdf(plan.docId, job.pageId);
          const probe = await probeViaContent(tabId, pdfUrl);
          if (!probe.pdf) {
            state.counts.blocked++;
            blockedAny = true;
            if (!state.blockedIssues.includes(plan.folderPath)) {
              state.blockedIssues.push(plan.folderPath);
              log(`Login required: ${plan.folderPath}`);
            }
            await saveState();
            continue;
          }
          try {
            await downloadOnce(pdfUrl, job.filePath);
            state.counts.downloaded++;
            await saveState();
          } catch (e) {
            state.counts.failed++;
            log(`Couldn't save ${job.filePath}: ${e instanceof Error ? e.message : String(e)}`);
            await saveState();
          }
          if (p < jobs.length - 1)
            await sleep(delayMs);
        }
        if (!blockedAny && !pauseRequested && id === runId && state.status === "running") {
          if (!state.completedIssues.includes(plan.folderPath))
            state.completedIssues.push(plan.folderPath);
          log(`Done: ${plan.folderPath}`);
          await saveState();
        }
      }
      if (id !== runId)
        return;
      if (pauseRequested)
        return finishAs("paused");
      state.status = "done";
      state.finishedAt = Date.now();
      log("All done!");
      await saveState();
      keepAliveOff();
    } catch (e) {
      if (id !== runId)
        return;
      state.status = "error";
      state.lastError = e instanceof Error ? e.message : String(e);
      state.finishedAt = Date.now();
      log(`Error: ${state.lastError}`);
      await saveState();
      keepAliveOff();
    }
  }
  function finishAs(status) {
    state.status = status;
    state.finishedAt = Date.now();
    log("Paused — ready to resume.");
    return saveState().then(() => keepAliveOff());
  }
  async function handleStart(options) {
    if (state.status === "running") {
      throw new Error("A download is already running.");
    }
    const mode = options?.mode === "publication" || options?.mode === "issue" ? options.mode : "all";
    const host = (options?.host ?? "").trim() || DEFAULT_HOST;
    const delayMs = typeof options?.delayMs === "number" && options.delayMs >= 0 ? options.delayMs : 500;
    runId++;
    const id = runId;
    pauseRequested = false;
    state = {
      ...freshState(),
      status: "running",
      mode,
      host,
      startedAt: Date.now(),
      completedIssues: state.completedIssues,
      blockedIssues: state.blockedIssues,
      log: state.log.slice(-40)
    };
    await saveState();
    keepAliveOn();
    runScrape(id, mode, host, options?.startUrl, options?.docId, delayMs, Boolean(options?.onlyPublic));
    return { ok: true };
  }
  function handleReset() {
    pauseRequested = true;
    state.completedIssues = [];
    state.blockedIssues = [];
    state.status = "idle";
    state.finishedAt = Date.now();
    state.lastError = undefined;
    log("Started over.");
    return saveState().then(() => ({ ok: true }), () => ({ ok: true }));
  }
  async function handleOpenArchive(host) {
    const h = (host ?? "").trim() || state.host || DEFAULT_HOST;
    await ensureArchiveTab(h, false);
    return true;
  }
  api.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || typeof msg !== "object" || typeof msg.type !== "string")
      return;
    switch (msg.type) {
      case "wake":
        sendResponse({ ok: true });
        return;
      case "getState":
        sendResponse({ ok: true, state });
        return;
      case "pause":
        pauseRequested = true;
        sendResponse({ ok: true });
        return;
      case "reset": {
        handleReset().then(() => sendResponse({ ok: true }), () => sendResponse({ ok: true }));
        return true;
      }
      case "openArchive": {
        handleOpenArchive(msg.host).then(() => sendResponse({ ok: true }), (e) => sendResponse({ ok: false, error: e instanceof Error ? e.message : String(e) }));
        return true;
      }
      case "start": {
        handleStart(msg.options).then((r) => sendResponse(r), (e) => sendResponse({ ok: false, error: e instanceof Error ? e.message : String(e) }));
        return true;
      }
    }
    return;
  });
  storageGet().then((s) => {
    state = s;
  }, () => {});
})();
