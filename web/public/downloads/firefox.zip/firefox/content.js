(() => {
  // src/content/content.ts
  var api = globalThis.browser ?? globalThis.chrome;
  api.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || typeof msg !== "object" || typeof msg.type !== "string")
      return;
    switch (msg.type) {
      case "ping":
        sendResponse({ ok: true });
        return;
      case "fetch": {
        handleFetch(String(msg.url)).then((res) => sendResponse(res), () => sendResponse({ ok: false, status: 0 }));
        return true;
      }
      case "probe": {
        handleProbe(String(msg.url)).then((res) => sendResponse(res), () => sendResponse({ status: 0, contentType: "", pdf: false }));
        return true;
      }
    }
    return;
  });
  async function handleFetch(url) {
    const res = await fetch(url, { credentials: "include" });
    if (!res.ok)
      return { ok: false, status: res.status };
    const text = await res.text();
    return { ok: true, status: res.status, text };
  }
  async function handleProbe(url) {
    const res = await fetch(url, {
      credentials: "include",
      headers: { Range: "bytes=0-1" }
    });
    const buf = await res.arrayBuffer();
    const head = new Uint8Array(buf, 0, Math.min(2, buf.byteLength));
    let sig = "";
    for (let i = 0;i < head.length; i++)
      sig += String.fromCharCode(head[i]);
    const ct = (res.headers.get("content-type") ?? "").toLowerCase();
    return {
      status: res.status,
      contentType: ct,
      pdf: sig === "%P" || ct.includes("application/pdf")
    };
  }
  setTimeout(() => {
    try {
      const p = api.runtime.sendMessage({ type: "wake" });
      if (p && typeof p.catch === "function")
        p.catch(() => {});
    } catch {}
  }, 250);
  try {
    document.documentElement.setAttribute("data-ext-id", api.runtime.id);
  } catch {}
})();
